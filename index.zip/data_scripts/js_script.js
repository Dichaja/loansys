$(document).ready(function(){

$('#department').change(function(){
  var department = $(this).val();
  $.ajax({
       type: 'POST',
       url:'../bin/data.php',
       data: {
               'dept' : department
             },

       success: function(data){
          
          $('#jobId').html(data);
       }
  });
});

})

$(document).on("change","#img_file",function(){

    var filename = $("#img_file").val();
    
    if(/^s*$/.test(filename)){

        $("#blankFile").text("No File Chosen..");
        $(".success").hide();
    }else{

        $("#blankFile").text(filename.replace("C:\\fakepath\\",""));
        $(".success").show();
    }
}) 

$(document).on('click','.close',function(){

    var select_attr = $(this).attr('select');
     if(!select_attr){
       var loc = window.location.href;
       var protocol = window.location.protocol;
       var host = location.host;
       var path = location.pathname;
       window.open(protocol+'//'+host+path,'_self');
     }
})

$(document).on('click','#open_search',function(){
  var usr = $(this).attr("data-usr");
  var form_data = $('#search-form').html();
  
   $("#drop-box").slideDown().css({"display":"block","background":"#FFF","overflow":"hidden","max-height":"500px"}).html(form_data);
    var close = '<img src="../img_file/search.png" width="18px" height="18px" id="close-search" style="cursor:pointer;" />';
    $("#search_icon").html(close);    
});

$(document).on('click','#close-search',function(){
   $("#drop-box").slideUp('slow').css("display","none");
   var open_search = '<img src="../img_file/search.png" width="18px" height="18px" id="open_search" style="cursor:pointer;" />';
    $("#search_icon").html(open_search);
  })
