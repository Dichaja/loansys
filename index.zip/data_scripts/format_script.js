
/*

 format page layout
 
*/

$(document).on('click','#datetimepicker, #picker',function(){
  $('#datetimepicker, #picker').datetimepicker({
   inline:false,
   changeMonth: true, 
   changeYear: true,
   yearRange: "1970:+nn",
   maxDate: '7m'
  });
})

$(document).on('click','#print_note',function(){
  $('.col-lg-9').hide();
  $('.close').hide();
  $('.display').css('width','95%');
  window.print()
  $('#myModal').hide();
  $('.col-lg-9').show();
})

$(document).on('click','#print_rpt',function(){
   window.print()
})

$(document).on('click','.expand_link',function(event){   
    $(this).addClass("expand_link_show").removeClass('expand_link').slideDown('slow');
})

$(document).on('click','.expand_link_show',function(event){   
    $(this).addClass("expand_link").removeClass('expand_link_show');
})


$(document).on('click','.close',function(){

  var select = $(this).attr('select');

  if(!select){
    var loc = window.location.href;
    var protocol = window.location.protocol;
    var host = location.host;
    var path = location.pathname;
    window.open(loc,'_self');
    //window.open(protocol+'//'+host+'/'+path,'_self');
  }else{

    $('#display').html('');
    let id = $(this).attr('select');
    let select_html = $('#'+id).html();
    $("#myModal").css("display","none");
    $('#'+id).html(select_html);
  }
})


$(document).on('click','#gen_pdf',function(){

let nbPages = 1;
let date = new Date();
let date_val = date.getDate();//return current year
$('#print_rpt, #gen_pdf').css('display','none');

   //create pdf file
  const options = {
      margin: 0.5,
      filename: 'summary_'+date_val+'.pdf',
      image: { 
        type: 'jpg', 
        quality: 0.95
      },
      html2canvas: { 
         dpi: 192, letterRendering: true, width: 1024, height: 1448 * nbPages
      },
      jsPDF: { 
        unit: 'in', 
        format: 'a4', 
        orientation: 'portrait' 
      }
    }

  const element = $('#display').html();
  html2pdf().from(element).set(options).save();

})

$(document).on('click','#get_report',function(){

let nbPages = 1;
let date = new Date();
let date_val = date.getDate();//return current year
$('#get_report, #print_rpt, #gen_pdf, #summary, .grid-2, select[name="select_action"]').css('display','none');
$('#header_wrap').css('display','block')
   //create pdf file
  const options = {
      margin: 0.5,
      filename: 'summary_'+date_val+'.pdf',
      image: { 
        type: 'jpg', 
        quality: 0.95
      },
      html2canvas: { 
         dpi: 192, letterRendering: true, width: 1096
      },
      jsPDF: { 
        unit: 'in', 
        format: 'a4', 
        orientation: 'portrait' 
      }
    }

  const element = $('.col-lg-9').html();
  html2pdf().from(element).set(options).save();

$('#get_report, #print_rpt, #gen_pdf, #summary, .grid-2, select[name="select_action"]').css('display','block');
$('#header_wrap').css('display','none');
})