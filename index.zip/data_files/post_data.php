<?php

session_start();
error_reporting(E_ALL ^ E_NOTICE);

require_once('../xsert/connect.php');
require_once('../data_files/sys_function.php');
date_default_timezone_set('Africa/Nairobi'); 

if($_POST['ac_id']){

      $expense = $_POST['expense_id'];
      $amt = $_POST['amt'];
      $date = $_POST['date'];
      $mop = $_POST['mop'];
      $acc_from = $_POST['mop_account'];
      $ac = $_POST['ac_id'];
      $paid_to = $_POST['paid_to'];
      $qty = $_POST['qty'];
      $expense_status = $_POST['expense_status'];
      $order_no = $_POST['order_cost_expenses'];
      $currency = $_POST['currency'];
      $cur_val = $_POST['cur_val'];
      $acc_to = $_POST['acc_to'];
      $acc_to_no = $_POST['acc_to_no'];
      $cur_index = $_POST['cur_select'];
      $cost = $_POST['cost'];

      $index=0;

       foreach($expense as $array){

         if($array!=''){

            if($qty[$index]==0)
                $qty[$index]=1;
            
            $inst = mysqli_query($connect,"INSERT INTO expense VALUES('".date('d').rand(1000,9999)."','$ac','$expense[$index]','".str_replace(",","",$cost[$index])."','".str_replace(",","",$qty[$index])."','$date','$mop','$acc_from','$acc_to','$acc_to_no','$paid_to','".$_SESSION['session_id']."') ");

            if($inst)
              $status = 'success';
            else
              $status = 'err';                
         }

         $index += 1;
       }

  echo $status;
}

if($_POST['edit_branch']){
  
  $id = $_POST['edit_branch'];
  $branch = $_POST['branch_name'];
  $addr = $_POST['address'];
  $email = $_POST['email'];
  $contacts = $_POST['contacts'];

  $upd = mysqli_query($connect,"UPDATE branches SET branch_name = '$branch', contact_email = '$email', contact_phone = '$contacts', address = '$addr' WHERE id='$id' ");

    if(mysqli_affected_rows($connect)){
        $status = 'success';   
    }

  echo $status;
}

if($_POST['member_id']){

  //define constant
  define("FILEREPOSITORY",'profile/');

      $id= $_POST['member_id'];


// --set image attributes for upload
  if(is_uploaded_file($_FILES['img_file']['tmp_name'])){

         $photo_name = $_FILES['img_file']['name'];
         $file_type = $_FILES['img_file']['type'];
         $photo_upd = $_FILES['img_file']['tmp_name'];
         
         //get the extension of the file
         $base = basename($photo_name);
         $extension = substr($base, strlen($base)-4, strlen($base));
         $allowed_extension = array(".jpg",".png",".jpeg",".PNG");

  if(in_array($extension,$allowed_extension)){
             if(!is_dir(FILEREPOSITORY.date("Y-m-d"))){
                  mkdir(FILEREPOSITORY.date("Y-m-d"));
                }

             $dir = date("Y-m-d").'/'.$id.'_'.strtotime(date('Y-m-d H:i:s')).$extension; //returns directory for uploading image
             move_uploaded_file($photo_upd,FILEREPOSITORY.date("Y-m-d").'/'.$id.'_'.strtotime(date('Y-m-d H:i:s')).$extension); //uploads file to respective directory
  }else{
        $response = 'Un-Supported Image File Format. <a href="" id="status_id">Try Again.!</a>';
    }
  //--//  
}

  if($response){

      $status = $response;
  }else{

$photo_dir = $_POST['photo_dir'];
 if($dir)
  $photo_dir = $dir;

    //insert query
    $query = "UPDATE clients SET first_name = '".ucfirst(strtolower($_POST['first_name']))."', last_name = '".ucfirst(strtolower($_POST['last_name']))."', contacts = '".$_POST['contacts']."', email = '".$_POST['email']."', residance = '".$_POST['residence']."', business_name = '".$_POST['occupy']."', gender = '".$_POST['gender']."', city = '".$_POST['city']."', date_modify = '".date("Y-m-d H:i:s")."', photo_dir = '$photo_dir', branch_id = '".$_POST['branch_details']."', data_id = '".$_POST['edit_id']."' WHERE id='$id' ";

    $upd = mysqli_query($connect, $query);
        
      if(mysqli_affected_rows($connect))
          $status = 'success';
  
  }

   echo $status;
 }

if($_POST['post_id']){

  $id = $_POST['post_id'];

  $upd = mysqli_query($connect,"UPDATE loan_entries SET date_entry='".$_POST['date']."', loan_amount = '".str_replace(",", "", $_POST['loan_amount'])."', interest = '".$_POST['interest']."', duration = '".$_POST['duration']."', period = '".$_POST['period']."' WHERE id='$id' ");

  if(mysqli_affected_rows($connect)){
    echo 'success';
  }else{
    echo mysqli_error($connect);
  }
}


if($_POST['edit_staff']){

  $id = $_POST['edit_staff'];

  $sql = mysqli_query($connect,"UPDATE staff SET staff_no = '".$_POST['staff_no']."', first_name = '".ucfirst(strtolower($_POST['first_name']))."',last_name = '".ucfirst(strtolower($_POST['last_name']))."', contacts = '".$_POST['contacts']."', email = '".$_POST['email']."', residance = '".$_POST['residance']."', job = '".$_POST['job']."', gender = '".$_POST['gender']."', nok = '".$_POST['nok']."', nok_contacts = '".$_POST['nok_contacts']."', branch_id = '".$_POST['branch_details']."' WHERE id='$id' ");

      if(mysqli_affected_rows($connect)){
        $status='success';
      }else{
        $status='err';
        $err=mysqli_error($connect);
      }
    echo $status.$err;
}

if($_POST['pay_loan']){

  $client_loan=$_POST['loan_client'];

  $id=date("d").rand(10000,99999);
  $date=date("Y-m-d",strtotime($_POST['pay_date']));
  $loan_id = $_POST['loan'];
  $allow_dup = $_POST['allow_dup'];

  if(mysqli_num_rows(mysqli_query($connect,"SELECT * FROM loan_payments WHERE loan = '$loan_id' AND pay_date='$date'")) && !$allow_dup){
      $status = 'duplicate';
  }else{
  if($_POST['pay_loan']!=0){
    $receipt = rand(1000,9999).'/23';
      $sql = mysqli_query($connect,"INSERT INTO loan_payments VALUES ('$id','".str_replace(",", "",$_POST['pay_loan'])."','$date','".$_SESSION['session_id']."','$client_loan','".$_POST['loan']."','$receipt','".date('Y-m-d H:i')."',NULL,'') ");
          if($sql){
              $status='success_'.$id.'_'.loan_status($connect,$loan_id,'');
              if(loan_status($connect,$loan_id,'') <= 0){
                  mysqli_query($connect,"UPDATE loan_entries SET status='00' WHERE id='$loan_id' ");
              }
             }else{
              $status='err';
             $err=mysqli_error($connect);
         }
    }
  }
     
  echo $status;
}

?>