<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require("../xsert/connect.php");
require_once('../data_files/sys_function.php');
require_once('../data_files/page_settings.php');

check_sess(); //check user loggin

?>
<!DOCTYPE html>
<html lang="en">
  <head>
   <meta content="charset=utf-8" /> 
    <?php include('../data_files/link_docs.php') ?>
   <title><?php echo sys_tab_hdr() ?></title>

<script type="text/javascript">

//closes dialog box
$(document).on('click','.close',function(){
  
  var loan = $("#loan_id2").val();
  if(loan==''){
    $(".modal").css("display","none");
    location.replace("client_list.php");
  }else{
    if(confirm("Do Wish to Cancel Loan...!!!")){
      $.ajax({
        type:'POST',
        url:'../data_files/amortize.php',
        data:{
          'delete_loan':loan
        },
        success:function(data){
          if(data==1){
            alert("Successfull...!!");
            location.replace("client_list.php");
          }else{
            alert("Something Went Wrong. Please Try Agan..!!!");
            location.replace("client_list.php");
          }
        }
      });
    }else{
      return false;
    }
  }
  
});

$(document).on('click','#submit',function(e){
   
  e.preventDefault();
  let content, load_content;
  var form = $('#edit_mem')[0];
  var formData = new FormData(form);
    $.ajax({
       type: 'POST',
       url: '../data_files/post_data.php',
       processData: false,
       contentType: false,
       data: formData,
       beforeSend:function(){
         load_content = $('#loading_wrap').html();
         $('.modal-content').removeClass('modal-small-size').toggleClass('modal-min-size');
         $('#display').html(load_content)
       },
       success:function(d){
         if(d)
          content = $('#success_wrap').html();          
            $('#display').html(content);
       }
    })
})

$(document).on('click','#submit_loan',function(event){

  event.preventDefault();
  var essential_form = $("#essential").html();

  $.ajax({
    type:"POST",
    url:"../data_files/data_src.php",
    data:$("#form2").serialize(),
    beforeSend:function(){
     $('#myModal_2').css({'z-index':'10','display':'block'}).html('<div class="modal-spin-wrap"><div class="modal-img-spin"><img src="../img_file/loading.gif" /></div></div>')
    },
    success:function(d){
      $('#myModal_2').css('display','none');
          
      var split = d.split("_");

      if(split[0]==1){
            $('#step_1').toggleClass('current-item');
            $('#step_2').addClass('current-item');
            $("#form_wrap").html(essential_form);
            $("#client_id2").val(split[2]);
            $("#loan_id").val(split[1]);              
          }else{
            alert("Un-successfull. Something Went Wrong...!!!");
          }
        $("#form2").trigger("reset");
     }
  })
})

$(document).on('click','#security_button',function(event){

  event.preventDefault();
  var guarantor_form = $("#guarantor_content").html();

  $.ajax({
    type:"POST",
    url:"../data_files/data_src.php",
    data:$("#form").serialize(),
    beforeSend:function(){
     $('#myModal_2').css({'display':'block','z-index':'10'}).html('<div class="modal-spin-wrap"><div class="modal-img-spin"><img src="../img_file/loading.gif" /></div></div>')
    },
    success:function(d){
      $('#myModal_2').css('display','none');
           
      var split = d.split("_");

          if(split[0]==1){
            $('#step_2').toggleClass('current-item');
            $('#step_3').addClass('current-item');
            $("#form_wrap").html(guarantor_form);
            $("#client_id3").val(split[2]);
            $("#loan_id2").val(split[1]);                 
          }else{
            alert("Something Went Wrong.Please Try Again..!!!");
          }
      $("#form").trigger("reset");
    }
  })

})

$(document).on('click','#guarantor_button',function(event){

  event.preventDefault();
  var content='', load_content='';

  $.ajax({
     type:'POST',
     url:'../data_files/data_src.php',
     data:$("#guarantor").serialize(),
     beforeSend:function(){
         load_content = $('#loading_wrap').html();
         $('.modal-content').removeClass('modal-small-size').toggleClass('modal-min-size');
         $('#display').html(load_content)
       },
       success:function(d){
         if(d=='success'){
             content = $('#success_wrap').html();
           }else{
             content = $('#error_wrap').html();
           }
         $('#display').html(content);
       }
  })

})

$(document).on('change','select[name="select_action"]',function(){
 
  var modal = $('#myModal').html();
  var action_val = $(this).val();
  var select = action_val.split('_');

  if(select[0]=='view'){

      $.ajax({
        type:'POST',
        url:'../data_files/data_src.php',
        data:{
          'get_client': select[1]
        },
        beforeSend:function(){
          $('#myModal').css({'display':'block','z-index':'6'}).html('<div class="modal-spin-wrap"><div class="modal-img-spin"><img src="../img_file/loading.gif" /></div></div>')
         },
        success:function(data){
          $('#myModal').html(modal)
          $('.modal-content').removeClass('modal-content, modal-small-size').toggleClass('modal-medium-size')
          $("#display").html(data);
        }
      })
  }

  if(select[0]=='statement'){

      $.ajax({
        type:'POST',
        url:'../data_files/data_src.php',
        data:{
          'pay_statement': select[1]
        },
        beforeSend:function(){
          $('#myModal').css({'display':'block','z-index':'6'}).html('<div class="modal-spin-wrap"><div class="modal-img-spin"><img src="../img_file/loading.gif" /></div></div>')
         },
        success:function(data){

          $('#myModal').html(modal)
          $('.modal-content').removeClass('modal-content, modal-large-size').toggleClass('modal-small-size')
          $("#display").html(data);
        }
      })
  }

  if(select[0]=='pop'){ //assigns new loan to client
    
  var form_display = $("#loan_form").html();
     
   $.ajax({
      type: 'POST',
      url: '../data_files/data_src.php',
      data:{
        'check_loan': 1,
        'check_client': select[1]
      },
      beforeSend:function(){
        $('#myModal_2').css({'display':'block','z-index':'6'}).html('<div class="modal-spin-wrap"><div class="modal-img-spin"><img src="../img_file/loading.gif" /></div></div>')
      },
      success: function(d){

       $('#myModal_2').css('display','none');
          $('#myModal').css('display','block');
          $('#myModal').html(modal);

          if(d!='success'){          
          
             $('.modal-content').removeClass('modal-large-size').toggleClass('modal-small-size');
             $("#display").html(form_display);
             $('#step_1').addClass('current-item')
             $("#client_id").val(select[1]);
          }else{

              var content = $('#warning_wrap').html();
              $('.modal-content').removeClass('modal-large-size').toggleClass('modal-min-size');
              $("#display").html(content);
          }
      }
  })              
}

if(select[0]=='edit'){
      $.ajax({
         type: 'POST',
         url: '../data_files/form_edit.php',
         data:{
           'edit_mem': select[1]
         },beforeSend:function(){
           $('#myModal_2').css({'display':'block','z-index':'6'}).html('<div class="modal-spin-wrap"><div class="modal-img-spin"><img src="../img_file/loading.gif" /></div></div>')
        },
        success:function(d){
            
            $('#myModal_2').css('display','none');
            $('#myModal').css('display','block').html(modal);
            $('.modal-content').removeClass('modal-large-size').toggleClass('modal-small-size');
            $('#display').html(d);
        }
      })
    }

  if(select[0]=='delete'){
    var user = $('#user_type').val();
    $.ajax({
        type:'POST',
        url:'../data_files/data_src.php',
        data:{
          'check_client':select[1]
        },
        success:function(data){
         if(confirm("Do You Wish to Delete...?")){
            if(data=='success'){
              if(confirm("Already in Use. Do You Wish To Continue")){
                if(user=='data_clerk')
                   alert('Denied. Please Contact Admin...!')
                else
                   del('clients', select[1])
               }else{
                 return false
               }
             } else {
                del('clients', select[1])
             }
          }else{
            return false;
          }
        }
    })
  }
});


function del(tab, index){

  $.ajax({
           type:'POST',
           url: '../data_files/data_src.php',
           data:{
             'del_id': index,
             'del_tab':tab
      },
      beforeSend:function(){
       $('#myModal_2').css({'display':'block','z-index':'6'}).html('<div class="modal-spin-wrap"><div class="modal-img-spin"><img src="../img_file/loading.gif" /></div></div>')
        },
        success: function(d){
         location.replace('client_list.php?action_msg='+d);
      }
  })
}

$(document).on('click','#open_search',function(){
  var usr = $(this).attr("data-usr");
  var form_data = $('#search-form').html();
  
   $("#drop-box").slideDown('slow').html(form_data);
    var close = '<img src="../img_file/search.png" width="18px" height="18px" id="close-search" style="cursor:pointer;" />';
    $("#search_icon").html(close);    
})

$(document).on('click','#close-search',function(){
   $("#drop-box").slideUp('slow').css("display","none");
   var open_search = '<img src="../img_file/search.png" width="18px" height="18px" id="open_search" style="cursor:pointer;" />';
    $("#search_icon").html(open_search);
  })

$(document).on('click','#loan', function(event){
   var loan = $("#loan_id2").val();

   $.ajax({
      type:"POST",
      url:"../data_files/amortize.php",
      data: $("#guarantor").serialize(),
      success:function(response){
        $("#amortize").html(response);
      }
   })
});

$(document).on('keyup','#loan_amount', function(){
 
 var myVal = "";
 var myDec = "";
 var attr = $(this).attr('id');
 var index_val = attr.split('_');
 var priceVal = $(this).val();

 var amtVal = $(this).val();
 var amt_split = amtVal.toString().split('.');

      // Filtering out the trash!
        amt_split[0] = amt_split[0].replace(/[^0-9]/g,""); 

      // Setting up the decimal part
        if ( ! amt_split[1] && amtVal.indexOf(".") > 1 ) {myDec = "."}
        if ( amt_split[1] ) { myDec = "."+ parseFloat(amt_split[1]) }

  // Adding the thousand separator
        while(amt_split[0].length > 3 ) {
            myVal = ","+amt_split[0].substr(amt_split[0].length-3, amt_split[0].length )+ myVal;
            amt_split[0]= amt_split[0].substr(0, amt_split[0].length-3);
            $("#loan_amount").val(amt_split[0]+myVal+myDec);
        }
})

$(document).on('keyup','#names',function() {

  var  search = $(this).val();
  var exp = new RegExp(search, "i");
  var results='',count=0, combo;

if(search){
  $.ajax({
    type:'POST',
    url:'../data_files/name_list.php',
    data:{
      'search':search,
      'name_cat': 'clients'
    },
    beforeSend:function(){
      $("#drop-box").slideDown().html('<div style="margin:auto;max-height250px;margin-bottom:50px;margin-top:50px;width:40%;"><img src="../img_file/loading.gif" /></div>');
    },success:function(data){
      if(data){
      $.each(data,function(key,value){
      combo = value.first_name+' '+value.last_name;
      combo2 = value.last_name+' '+value.first_name;
       if(value.first_name.search(exp) != -1 || value.last_name.search(exp) != -1 || combo.search(exp) != -1 || combo2.search(exp) != -1){
        count+=1;
         results += '<div class="list_items" data="'+value.id+'">'+value.first_name+' '+value.last_name+'</div>';
        }
     })
    }

     if(results)
      $("#drop-box").html(results);
     else 
      $("#drop-box").slideUp();
    }
  })
} 
else 
  $("#drop-box").slideUp();
})

$(document).on('click','.list_items',function(){

   var id = $(this).attr('data');
   var txt = $(this).html();

   $('#names').val(txt).css('text-transform','capitalize');
   $('#member_id').val(id);

   //displays search form
    var form_data = $('#search-form').html();
    $("#search_wrap").css({"border-left":"solid 1px #225C97","border-right":"solid 1px #225C97","border-top":"solid 1px #225C97"});
    $("#drop-box").css({"display":"block","background":"#FFF","overflow":"hidden","max-height":"500px"}).html(form_data);
     $('#open_search').attr('id','close-search');
 })

$(document).on('blur','#edit_id',function(){
   var val = $('#edit_id').val();
     $.ajax({
       type: 'POST',
       url: '../data_files/data_src.php',
       data:{
         'check_mem_id': val
       },
       success:function(d){
         if(d=='success'){
           $('#edit_id').css('border','solid 1px #F00').focus()
           $('#err_msg').html('( Member Id Alreay in Use...! )');
           $('#submit').attr('id','disabled');
         }else{
           $('#edit_id').css('border','solid 1px #CCC');
           $('#err_msg').html('');
           $('#disabled').attr('id','submit');
         }
       }
    })
})

$(document).on('click','#disabled',function(){
  $('#edit_id').focus();
})

</script>
</head>

<body>


<?php

$limit = 40; //how many items to show per page

if($_POST['rows']){

     $limit=$_POST['rows'];
     $gender = $_POST['gender_2'];
     $address = mysqli_real_escape_string($connect,$_POST['address_2']);
     $client = $_POST['client_2'];
     $client2 = $_POST['search_client'];
     $month2=$_POST['month_2'];

  if($_POST['rows']=='All'){
    $limit = mysqli_num_rows(mysqli_query($connect,"SELECT * FROM clients")); //returns all rows
  }else{
    $limit=$_POST['rows']; //returns specified number of rows
  }
}

if($_POST['post_search']){

     $client = $_POST['mem_names'];
     $address = $_POST['address'];
     $gender = $_POST['gender']; 
     $month = $_POST['month'];
     $branch = $_POST['branch_details'];
     $client_id = $_POST['member_id'];
  }

  if($_GET['page']){

       $client = $_GET['client'];
       $address = $_GET['address'];
       $gender = $_GET['gender'];
       $client = $_GET['client2']; 
       $page = $_GET['page'];
       $month = $_GET['month'];
       $limit = $_GET['limit'];
       $branch = $_GET['branch_details'];
    } 

  if($_POST['pagination']){
         $page = $_POST['pagination'];
    }
      

    $targetpage = "client_list.php";   //your file name  (the name of this file)    
    
    if($page) 
        $start = ($page - 1) * $limit;          //first item to display on this page
    else
        $start = 0;                             //if no page var is given, set start to 0

   
     $qry = "SELECT * FROM clients c, branches b ";
       if(!$_SESSION['general_user'])
          $qry .=", user_log u ";
            $qry .= " WHERE c.branch_id = b.id AND c.status='01' AND ";
          if(!$_SESSION['general_user'])
              $qry .= " c.branch_id = u.user_branch AND ";
        if($client !=''){
            if($client_id)
              $qry .= " c.id = '$client_id' AND ";
              else
                 $qry .= " CONCAT(c.first_name,' ',c.last_name) LIKE  '%$client%' AND ";
             }
         if($address!='')
                $qry .= " c.residence = '".$address."' AND ";
            if($month!='')
                $qry .= " c.monthname(date_created) = '".$month."' AND ";
             if($gender!='')
                  $qry .= " c.gender = '".ucfirst($gender)."' AND ";
              if(!$_SESSION['general_user'])
                    $qry .= "u.id='".$_SESSION['session_id']."' AND ";
                 if($branch)
                     $qry .= " b.id = '$branch' AND ";
               $qry2 .= $qry.' 1 ';
             $qry .= " 1 ORDER BY c.first_name, c.last_name ASC LIMIT $start, $limit ";
             

    $query = mysqli_query($connect,$qry2); //total registered clients
     $total_pages= mysqli_num_rows($query); 

    $result = mysqli_query($connect,$qry);

    /* Setup page vars for display. */
    if ($page == 0) $page = 1;                  //if no page var is given, default to 1.
    $prev = $page - 1;                          //previous page is page - 1
    $next = $page + 1;                          //next page is page + 1
    $lastpage = ceil($total_pages/$limit);      //lastpage is = total pages / items per page, rounded up.
    $lpm1 = $lastpage - 1;

    $search = '';
       if($client)
         $search .= $client.', ';
        if($gender)
            $search .= $gender.', ';
          if($month)
             $search .=  ' of '.$month.', ';
           if($branch){
              $sql = mysqli_query($connect,"SELECT * FROM branches WHERE id='$branch' ");
                $r = mysqli_fetch_array($sql);
                 $search .= $r[1].', ';
           }
?> 
   <!-- Main Content Wrapper -->
<div class="main_bd_wrap">
  
  <?php

    tp_hdr(); //Page Header, Menu
       side_menu_content(); // Side Menu
      ?>
         <!-- Main Content Side-Right -->
           <div class="main-sidebar col-lg-9">
<div style="width:95%;margin: auto;">
  <?php if($_GET){ include('../data_files/action_msg.php'); } ?>
  <div class="grid-2" style="display: grid;">
    <div></div>
    <div style="text-align: right;">
      <!--Search Wrapper -->
                <form name="form1" method="post" action="client_list.php" id="form1">
                  <input type="hidden" name="post_search" value="1" />
                    <div style="width:100%;height:40px;display: grid;grid-template-columns: 2fr 1fr;">
                     <div style="height:40px;border:solid 1px #CCC;background-color:#fff">
                        <input type="text" name="mem_names" value="" placeholder="Search Client" style="width:85%;height:90%;border:solid 1px #fff;" id="names" autocomplete="off">
                          <img src="../img_file/search.png" id="open_search" data-usr="" width="18px" height="18px">
                          <input type="hidden" name="member_id" value="" id="member_id">
                      <div id="drop-box" class="drop_down drop_large_size"></div>
                     </div> 
                    <input type="submit" name="search" value="Search" class="button_search">
                  </div>                      
                </form>
      </div>
  </div>
  <div class="report_header"><span>List of Member(s) <?php echo $search ?> Total : <?php echo $total_pages ?></span><span id="print_rpt"><img src="../img_file/print-icon.svg" width="20" height="20"></span></div>
  <form name="form_list" id="form_list" method="post" action="client_list.php">
    <table align="center" cellpadding="5" cellspacing="0" class="report_display" width="100%">
     <tr>
      <td>No</td>
      <td>Id</td>
      <td>Member</td>
      <td>Gender</td>
      <td>Contacts</td>
      <td>Residence</td>
      <td>Business Name</td>
      <td>Branch</td>
      <td colspan="2" id="row">&nbsp;</td>
     </tr>
     <?php
       
      if(mysqli_num_rows($result)){
        $count=0;
        while($rw=mysqli_fetch_array($result)){
        ?>
        <tr>
         <td><?php echo $start += 1 ?></td>
         <td><?php echo $rw['data_id'] ?></td>
         <td style="text-transform:capitalize;"><?php echo strtolower($rw[1].' '.$rw[2]) ?></td>
         <td><?php echo $rw[7] ?></td>
         <td><?php echo $rw[3] ?></td>
         <td><?php echo $rw[5] ?></td>         
         <td><?php echo $rw[6] ?></td>
         <td><?php echo $rw[16] ?></td>         
         <td id="row">
          <select name="select_action" id="<?php echo $rw[0] ?>" class="text-input" style="width:80px;">
            <option value="">Action</option>
            <option value="edit_<?php echo $rw[0] ?>" id="edit_<?php echo $rw[0] ?>">Edit</option>
            <option value="pop_<?php echo $rw[0] ?>" id="pop_<?php echo $rw[0] ?>">Assign Loan</option>
            <option value="view_<?php echo $rw[0] ?>">Loan History</option>
            <option value="statement_<?php echo $rw[0] ?>">View Statement</option>
            <option value="delete_<?php echo $rw[0] ?>" id="delete_<?php echo $rw[0] ?>">Delete</option>
         </select>
          </td>
         </tr>
        <?php
        }
       }else{
         
        ?>
          <tr>
               <td colspan="10"class="bottom_line" style="color: #145FA7;"><div style="width:40%;height:400px;padding:20px;">No Search Record(s) Found....</div></td>
           </tr>
        <?php
       }
      ?>
        <tr  id="top">
          <td colspan="10">
           <div style="float:left;">Total : <?php echo $total_pages ?>&nbsp;Client(s)</div>
           <div style="float:right;" >
           <form name="form2" method="post" action="">
             <input type="hidden" value="<?php echo $client ?>" name="client_2" />
             <input type="hidden" value="<?php echo $client2 ?>" name="search_client" />
             <input type="hidden" value="<?php echo $address ?>" name="address_2" />
             <input type="hidden" value="<?php echo $gender ?>" name="gender_2" />
              Row Number<select name="rows" onchange="form.submit();" style="height:30px;width:80px">
                      <?php
                         $array = array("40","100","250","500","All");
                         foreach($array as $nums){
                           if($_POST['rows']){
                             if($_POST['rows']==$nums){
                               echo '<option value="'.$nums.'" selected="selected">'.$nums.'</option>';
                             }else{
                               echo '<option value="'.$nums.'">'.$nums.'</option>';
                             }
                           }else{
                             echo '<option value="'.$nums.'">'.$nums.'</option>';
                           }
                         }
                       ?>
                        </select>
              </form>&nbsp;&nbsp;
          <?php 
             echo "<a href=\"$targetpage?page=$first&limit=$limit&address=$address&client=$client&client2=$client2&gender=$gender&month=$month\">First</a>&nbsp;<a href=\"$targetpage?page=$prev&limit=$limit&address=$address&client=$client&client2=$client2&gender=$gender&month=$month\">Prev</a>&nbsp;&nbsp;".$page.' of '.$lastpage."&nbsp;&nbsp;<a href=\"$targetpage?page=$next&limit=$limit&address=$address&client=$client&client2=$client2&gender=$gender&month=$month\">Next</a>&nbsp;<a href=\"$targetpage?page=$lastpage&limit=$limit&address=$address&client=$client&client2=$client2&gender=$gender&month=$month\">Last</a>" ?>
           </div></td>
       </tr>
    </table> 
   </form>
  </div>
</div>

<div id="essential">
<form method="post" name="form" id="form">
    <input type="hidden" name="client2" id="client_id2" />
    <input type="hidden" name="loan" id="loan_id" />
      <div class="form-group">
        <div class="label">Security Name</div>
        <input type="text" name="security_name" class="text-input" />
      </div>
      <div class="form-group">
        <div class="label">Value</div>
        <input type="text" name="value" class="text-input" id="loan_amount" value="00.0" />
      </div>
      <div class="form-group">
        <div class="label">Type</div>
        <input type="text" name="type_sec" class="text-input" />
      </div>
      <div class="form-group">
        <div class="label">Serial No</div>
        <input type="text" name="serial" class="text-input" />
      </div>      
      <div class="form-group">
        <div class="label">Description</div>
        <input type="text" name="desc" class="text-input" />
      </div>
      <div class="form-group">
        <button type="submit" name="btn-security" class="button-input" id="security_button">Submit</button>
      </div>
      <input type="hidden"  value="entry" name="security-entry" />
    </form>
  </div>
  <div id="guarantor_content">
    <form method="post" name="guarantor" id="guarantor">
    <input type="hidden" name="client3" id="client_id3" />
    <input type="hidden" name="loan2" id="loan_id2" />
       <!--<div style="display: grid;grid-template-columns: 4fr 2fr">
         <div></div>
         <div>
           <div style="display: grid;grid-template-columns: repeat(2, 1fr);">
             <span id="loan" class="loan">Amortize Loan</span>
             <span id="print" class="loan">Print</span>
           </div>
         </div>
       </div>
      <div class="form-group" id="amortize">
      </div>-->
      <div class="form-group">
        <div class="label">Names</div>
        <input type="text" name="guarantor_name" class="text-input" />
      </div>
      <div class="form-group">
        <div class="label">Contacts</div>
        <input type="text" name="contacts" class="text-input" />
      </div>
      <div class="form-group">
        <div class="label">Email</div>
        <input type="text" name="email" class="text-input" />
      </div>
      <div class="form-group">
        <div class="label">Gender</div>
        <select name="gender" class="text-input">
            <option selected="selected"  value="">--Select--</option>
            <option value="Male">Male</option>
            <option value="Female">Female</option>
        </select>
      </div>      
      <div class="form-group">
        <div class="label">Residence</div>
        <input type="text" name="residence" class="text-input" />
      </div>
      <div class="form-group">
        <div class="label">Occupation</div>
        <input type="text" name="occupy" class="text-input" />
      </div>
      <div class="form-group">
        <button type="submit" name="btn-guarantor" class="button-input" id="guarantor_button">Submit</button>
      </div>
      <input type="hidden" name="guarantor-entry"  value="entry" />
     </form>
</div>
<div id="loan_form">

<div class="form_header">Assign Loan Form</div>
  <section class="step-wizard">
     <ul class="step-wizard-list">
       <li class="step-wizard-item" id="step_1">
           <span class="progress-count">1</span>
           <span class="progress-label">Loan Details</span>
       </li>
       <li class="step-wizard-item" id="step_2">
           <span class="progress-count">2</span>
           <span class="progress-label">Loan Security</span>
       </li>
       <li class="step-wizard-item" id="step_3">
           <span class="progress-count">3</span>
           <span class="progress-label">Loan Guarantor</span>
       </li>
     </ul>
   </section>
  <section id="form_wrap">
    <form method="post" name="form" id="form2">
      <input type="hidden" name="client" id="client_id" />
      <div class="form-group">
        <div class="label">Loan Amount</div>
        <input type="text" name="loan_amount" class="text-input" id="loan_amount" />
      </div>
      <div class="form-group">
      <div style="display:grid; grid-template-columns: repeat(2, 1fr);gap:10px;">
        <div>
          <div class="label">Period Category</div>
           <select name="duration" class="text-input">
            <option selected="selected">Select</option>
            <option value="day">Day</option>
            <option value="month">Month</option>
            <option value="year">Year</option>
           </select>
        </div>
         <div>
           <div class="label">Period</div>
           <input type="text" name="period" class="text-input" />
         </div>
      </div>
      <div class="form-group">
        <div class="label">Interest Rate</div>
        <input type="text" name="interest" class="text-input" />
      </div>
      <div class="form-group">
        <div class="label">Lending Date</div>
        <input type="text" name="date" class="text-input" id="datetimepicker" autocomplete="off" value="<?php echo date('Y-m-d H:i:s') ?>" />
      </div>
      <div class="form-group" id="button">        
        <button type="submit" name="btnSubmit" class="button-input" id="submit_loan">Submit</button>
      </div>
    </form>
</div>

<!-- returns seach form elements -->
<div id="search-form">
    <div class="form_element">
     <input type="text" name="address" placeholder="Address" class="text-input"/>
    </div>
    <div class="form_element">
      <select name="gender" id="gender" class="text-input">
        <option selected="selected" value="">Gender</option>
        <option value="male">Male</option>
        <option value="female">Female</option>
      </select>
    </div>
    <div class="form_element">
      <select name="month" id="gender" class="text-input">
        <option selected="selected" value="">Search By Month</option>
         <?php 
          $array_month = array('January','February','March','April','May','June','July','August','September','October','November','December');
          foreach($array_month as $val){
            echo '<option value="'.$val.'">'.$val.'</option>';
          }
        ?>
      </select>
    </div>
    <?php
      if($_SESSION['general_user']) { ?>
<div class="form_element">
  <select name="branch_details" class="text-input">
    <option value="" selected="selected">Search Branch</option>
     <?php
       $sql = mysqli_query($connect,"SELECT * FROM branches");
         if(mysqli_num_rows($sql)){
            while($r = mysqli_fetch_array($sql)){
              if($r[1])
               echo '<option value="'.$r['id'].'">'.$r['branch_name'].'</option>';
           }
        }
      ?>
   </select>
</div>
<?php } 

      echo footer_sec(); //footer section
    ?>
  </div>
  </body>
</html>