<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require("../xsert/connect.php");
require_once('../data_files/sys_function.php');
require_once('../data_files/page_settings.php');

check_sess(); //check user loggin

?>
<!DOCTYPE html>
<html lang="en">
  <head>
   <meta content="charset=utf-8" />    
   <title><?php echo sys_tab_hdr() ?></title>

<?php include('../data_files/link_docs.php') ?>
<script type="text/javascript" src="../data_scripts/jspdf.debug.js"></script>
<script type="text/javascript" src="../data_scripts/html2canvas.min.js"></script>
<script type="text/javascript" src="../data_scripts/html2pdf.min.js"></script>

<script type="text/javascript">

//closes dialog box
$(document).on('click','.pop',function(){

 var myModal = $('#myModal');
     myModal.css("display","block");
 var form_display = $("#loan").html();
 var period = $(this).attr("loan-period");
 var data_pop = $(this).attr("data");
 var index  = data_pop.split("_");

    $.ajax({
        type:"POST",
        url:"../data_files/data_src.php",
        data:{
          'get_loan':index[0],
          'period':period
        },
        success:function(data){
          $("#display").html(data);
            $("#client_id").val(index[0]);
        }
    });
     
})

$(document).on('click','#spanModal',function(){
    var select_id = $(this).attr('select');
    var select_data = $("#"+select_id).html();
    var split=select_id.split("_");//returns id index
    $("#myModal").css("display","none");
    $(".view_form").css("display","none");
    $("#"+select_id).html(select_data);
})

$(document).on('click','.loan',function(){
  var id = $(this).attr('id');
  var loan = $(this).attr('data-set');
  var pay_form = $('#details').html();

  $("#loan").removeClass('loan').html("Pay Loan");
  
  $.ajax({
    type:'POST',
    url:'../data_files/data_src.php',
    data:{
      'armotize':loan
    },
    success:function(data){
      $("#loan").addClass('loan2');
      $("#details").html(data);
    }
  });
});

$(document).on('click','.loan2',function(){
  var loan = $(this).attr('data-set');
  $.ajax({
    type:'POST',
    url:'../data_files/data_src.php',
    data:{
      'get_loan':loan
    },
    success:function(data){
      $("#display").html(data);
    }
  })
})

$(document).on('click','#extend',function(){
  var row=('<div class="grid-2 margin-2">'
              +'<div>Loan Period</div>'
              +'<div><input type="text" name="period" value="" class="text-input" id="period" /></div>'
            +'</div>'
            +'<div class="grid-2 margin-2">'
               +'<div>Issue Date</div>'
               +'<div><input type="text" name="new_date" class="text-input" id="datetimepicker" /></div>'
             +'</div>');
     $("#extend_loan").html(row);
     $(".pay_data").css('display','none');
     $('#submit_loan').attr('id','submit_extend');
})

$(document).on('click','#apprehend',function(){
  $("#removeRow").css("display","none");
  $("#amount_entry").css('display','block');
});

$(document).on('change','select[name="select_action"]',function(){

  var loan_pop = $(this).val();
  var index = loan_pop.split("_");
  var period = $(this).attr("loan-period");
  var id = $(this).attr('id');
  var split = id.split("_");
  var user_type = $("#usr").val();
  var srch_val = $('#srch_val').val();
  var modal = $('#myModal').html();  

  if(index[1]=='loan'){ 

    $.ajax({
        type:"POST",
        url:"../data_files/data_src.php",
        data:{
          'get_loan':index[0],
          'srch_val': srch_val
        },
        beforeSend:function(){
          $('#myModal').css({'display':'block','z-index':'6'}).html('<div class="modal-spin-wrap"><div class="modal-img-spin"><img src="../img_file/loading.gif" /></div></div>')
         },
        success:function(data){

             $('#myModal').html(modal);
             $('.modal-content').removeClass('modal-small-size').addClass('modal-medium-size')
             $("#display").html(data);
             $("#client_id").val(index[0]);
          $("#spanModal").attr("select",id);
        }
    })
  }

if(index[1]=='statement'){

   var client = $('#postClient_'+split[1]).val();

      $.ajax({
        type:'POST',
        url:'../data_files/data_src.php',
        data:{
          'pay_statement': client,
          'post_loan' : index[0]
        },
        beforeSend:function(){
          $('#myModal').css({'display':'block','z-index':'6'}).html('<div class="modal-spin-wrap"><div class="modal-img-spin"><img src="../img_file/loading.gif" /></div></div>')
         },
        success:function(data){

          $('#myModal').html(modal)
          $('.modal-content').removeClass('modal-content, modal-large-size').toggleClass('modal-small-size')
          $("#display").html(data);
          $("#spanModal").attr("select",id);
        }
      })
  }
  if(index[1]=='view'){

     $.ajax({
        type:"POST",
        url:"../data_files/data_src.php",
        data:{
          'loan_pay':index[0] 
        },
        beforeSend:function(){
          $('#myModal').css({'display':'block','z-index':'6'}).html('<div class="modal-spin-wrap"><div class="modal-img-spin"><img src="../img_file/loading.gif" /></div></div>')
         },
        success:function(data){
          $('#myModal').css('display','none');
          $("#rows_"+split[1]).after(data).slideDown('slow');
        }
    });
}

if(index[1]=='edit'){

  var loan_id;

     $.ajax({
        type:"POST",
        url:"../data_files/form_edit.php",
        data:{
          'edit_loan':index[0]
        },
        beforeSend:function(){
          $('#myModal').css({'display':'block','z-index':'6'}).html('<div class="modal-spin-wrap"><div class="modal-img-spin"><img src="../img_file/loading.gif" /></div></div>')
         },
        success:function(data){

          $('#myModal').html(modal)
          $('.modal-content').toggleClass('modal-medium-size').addClass('modal-small-size');
          $("#display").html(data);
          loan_id = $('#loan_id').val();
          $('#post_id').val(loan_id);
          $('#step_1').addClass('current-item');
          $('#step_2').addClass('current-item');
          $('#step_3').addClass('current-item');
        }
    });
}

if(index[1]=='delete'){

  var user = $('#user_type').val();
  
     $.ajax({
        type:"POST",
        url:"../data_files/data_src.php",
        data:{
          'delete_loan':index[0]
        },
        success:function(data){
          if(data=='1'){
            if(confirm("Already in Use. Do You Wish To Continue")){
                if(user=='data_clerk')
                   alert('Denied. Please Contact Admin...!')
                else
                  delete_loan(index[0]);
            }else{
              return false;
            }
          }else{
            if(confirm("Do You want to Delete..?")){
               delete_loan(index[0]);
            }else{
              return false;
            }
          }
        }

    });
  }

if(index[1]=='amortize'){

     $.ajax({
        type:"POST",
        url:"../data_files/amortize.php",
        data:{
          'loan2':index[0]
        },
        beforeSend:function(){
          $('#myModal').css({'display':'block','z-index':'6'}).html('<div class="modal-spin-wrap"><div class="modal-img-spin"><img src="../img_file/loading.gif" /></div></div>')
         },
        success:function(data){

          $('#myModal').html(modal)
          $('.modal-content').removeClass('modal-small-size').addClass('modal-medium-size')
          $("#display").html(data);
          $("#spanModal").attr("select",id);
        }
    })
  }

})

$(document).on('keyup','#client',function() {

  var  search = $(this).val();
  var exp = new RegExp(search, "i");
  var results='',count=0, combo;

if(search){
  $.ajax({
    type:'POST',
    url:'../data_files/name_list.php',
    data:{
      'search':search,
      'name_cat': 'clients'
    },
    beforeSend:function(){
      $("#drop-box").slideDown().html('<div style="margin:auto;max-height250px;margin-bottom:50px;margin-top:50px;width:40%;"><img src="../img_file/loading.gif" /></div>');
    },success:function(data){
      if(data){
        $.each(data,function(key,value){
             combo = value.first_name+' '+value.last_name;
             combo2 = value.last_name+' '+value.first_name;
          if(value.first_name.search(exp) != -1 || value.last_name.search(exp) != -1 || combo.search(exp) != -1 || combo2.search(exp) != -1){
             count+=1;
                 results += '<div class="list_items" data="'+value.id+'">'+value.first_name+' '+value.last_name+'</div>';
            }
        })
      }

     if(results)
      $("#drop-box").html(results);
     else 
      $("#drop-box").slideUp();
    }
  })
} 
else 
  $("#drop-box").slideUp();
})

$(document).on('click','.list_items',function(){

   var id = $(this).attr('data');
   var txt = $(this).html();

   $('#client').val(txt).css('text-transform','capitalize');
   $('#client_id').val(id);

   //displays search form
    var form_data = $('#search-form').html();
    $("#search_wrap").css({"border-left":"solid 1px #225C97","border-right":"solid 1px #225C97","border-top":"solid 1px #225C97"});
    $("#drop-box").css({"display":"block","background":"#FFF","overflow":"hidden","max-height":"500px"}).html(form_data);
     $('#open_search').attr('id','close-search');
 })

$(document).on('keyup','#pay', function(){
 
 var myVal = "";
 var myDec = "";

 var amtVal = $(this).val();
 var amt_split = amtVal.toString().split('.');

      // Filtering out the trash!
        amt_split[0] = amt_split[0].replace(/[^0-9]/g,""); 

      // Setting up the decimal part
        if ( ! amt_split[1] && amtVal.indexOf(".") > 1 ) {myDec = "."}
        if ( amt_split[1] ) { myDec = "."+ parseFloat(amt_split[1]) }

  // Adding the thousand separator
        while(amt_split[0].length > 3 ) {
            myVal = ","+amt_split[0].substr(amt_split[0].length-3, amt_split[0].length )+ myVal;
            amt_split[0]= amt_split[0].substr(0, amt_split[0].length-3);            
        }
      $("#pay").val(amt_split[0]+myVal+myDec);
});

function delete_loan(loan){
  $.ajax({
    type:"POST",
    url:"../data_files/data_src.php",
    data:{
      'confirm_loan_delete' : loan
    },
    success:function(data){
      if(data=='1'){
      alert("Successfull...!!!");
      location.replace("loan_activity.php");
      }else{
        alert("Something Went Wrong. Please Try Again...!!!");
      }
    }
  })
}


$(document).on('keyup','#loan_amount', function(){
 
 var myVal = "";
 var myDec = "";
 var attr = $(this).attr('id');
 var index_val = attr.split('_');
 var priceVal = $(this).val();

 var amtVal = $(this).val();
 var amt_split = amtVal.toString().split('.');

      // Filtering out the trash!
        amt_split[0] = amt_split[0].replace(/[^0-9]/g,""); 

      // Setting up the decimal part
        if ( ! amt_split[1] && amtVal.indexOf(".") > 1 ) {myDec = "."}
        if ( amt_split[1] ) { myDec = "."+ parseFloat(amt_split[1]) }

  // Adding the thousand separator
        while(amt_split[0].length > 3 ) {
            myVal = ","+amt_split[0].substr(amt_split[0].length-3, amt_split[0].length )+ myVal;
            amt_split[0]= amt_split[0].substr(0, amt_split[0].length-3);            
        }
      $("#loan_amount").val(amt_split[0]+myVal+myDec);
})

$(document).on('click','#edit_loan',function(e){

    e.preventDefault();
    load_content = $('#loading_wrap').html();
    $.ajax({
       type:'POST',
       url: '../data_files/post_data.php',
       data: $('#form2').serialize(),
        beforeSend:function(){
        $('#myModal_2').css({'display':'block','z-index':'10'}).html('<div class="modal-spin-wrap"><div class="modal-img-spin"><img src="../img_file/loading.gif" /></div></div>')
      },
      success:function(d){

         $('.modal-content').removeClass('modal-small-size').toggleClass('modal-min-size');
          $('#myModal_2').css('display','none');
           if(d.trim()=='success'){
               content = $('#success_wrap').html();
             }else{
             content = $('#error_wrap').html();
           }
         $('#display').html(content);
      }
    })
})

$(document).on('click','#submit_loan',function(e){

   e.preventDefault();
   var loan = $('input[name="loan"]').val();
     $.ajax({
        type: 'POST',
        url: '../data_files/post_data.php',
        data:$('#loans').serialize(),
        beforeSend:function(){
          $('#myModal_2').css({'z-index':'7','display':'block'}).html('<div class="modal-spin-wrap"><div class="modal-img-spin"><img src="../img_file/loading.gif" /></div></div>')
         },
         success:function(d){
          let date = $('#datetimepicker').val();
          let amt_paid = $('#pay').val();
          let client = $('#client_loan').val(), loan = $('#loan_id').val();

          $('#display').html('');
          $('#myModal_2').css('display','none');
          $('.modal-content').toggleClass('modal-min-size');

          var split = d.split('_');
           if(split[0].trim()=='success'){
            display_receipt(loan,split[1]);
            console.log(split[2])
           }else if(d=='duplicate'){
              
             content = $('#warning_wrap').html();
             $('#display').html(content);             
             $('#display div').css('width','80%')
             $('#warning_msg').html('<span style="display:inline-block;width:100%">Payment Details Already Exist. Do You wish to Continue...!</span><div style="display:grid;grid-template-columns: repeat(2,1fr);gap:10px;width:35%;margin:15px auto;"><span id="yes_dup" data-loan="'+loan+'" data-client="'+client+'" data-paid="'+amt_paid+'" data-date="'+date+'">Yes</span><span id="no_dup">No</span></div>');
           }else{

             content = $('#error_wrap').html();
             $('#display').html(content);
             console.log(d)
           }
        }
    })
})

$(document).on('click','#submit_extend',function(){


})

$(document).on('click','#yes_dup',function(){

    let client = $(this).attr('data-client'), loan = $(this).attr('data-loan'), amt_paid = $(this).attr('data-paid'), date = $(this).attr('data-date');
    $.ajax({
       type: 'POST',
       url: '../data_files/post_data.php',
       data:{
         'pay_loan': amt_paid,
         'loan_client': client,
         'loan' : loan,
         'pay_date' : date,
         'allow_dup' : 1
       },
        beforeSend:function(){
          $('#display').html('<div class="modal-spin-wrap"><div class="modal-img-spin"><img src="../img_file/loading.gif" /></div></div>')
       },
       success:function(d){
         var split = d.split('_');
           if(split[0].trim()=='success'){
               display_receipt(loan,split[1]);
             }else{
               content = $('#error_wrap').html();
               $('#display').html(content);
           }
       }
    })
})

$(document).on('click','#no_dup', function(){
    var loc = window.location.href;
    window.open(loc,'_self');
})



function display_receipt(loan,pay_id){

   $.ajax({
      type:'POST',
      url: '../data_files/data_src.php',
      data:{
        'get_receipt':loan,
        'pay_id':pay_id
      },
      success:function(d){
        $('#display').html(d);
      }
   }) 
}

</script>
</head>
<body>

<?php

$limit = 40;
$year = date('Y');            
//how many items to show per page

if($_POST['rows']){
      
      $client = $_POST['client'];
      $client_id = $_POST['client_id'];
      $month = $_POST['month'];
      $year = $_POST['year'];
      $pay_status = $_POST['pay_status'];
      $date = $_POST['date'];
      $date2 = $_POST['date2'];
      $page = $_POST['page'];

if($_POST['rows']=='All'){
    $limit = mysqli_num_rows(mysqli_query($connect,"SELECT * FROM loan_entries")); //returns all rows
  }else{
    $limit=$_POST['rows']; //returns specified number of rows
  }
}

if($_POST['post_search']){

  $client_src = $_POST['client'];
  $client_id = $_POST['client_id'];
  $month = $_POST['month'];
  $year = $_POST['year'];
  $pay_status = $_POST['pay_status'];
  $date = $_POST['date'];
  $date2 = $_POST['date2'];
  $branch = $_POST['branch_details'];

}

if($_GET['page']){

      $client = $_GET['client'];
      $client_id = $_GET['client_id'];
      $month = $_GET['month'];
      $year = $_GET['year'];
      $pay_status = $_GET['pay_status'];
      $date = $_GET['date'];
      $date2 = $_GET['date2'];
      $page = $_GET['page'];
      $limit=$_GET['limit']; 
      $branch = $_GET['branch'];      
} 

if($_GET['client_id']){
  
   $client_id = $_GET['client_id'];
}

if($_POST['edit_loan']){

  $id = $_POST['edit_loan'];
  $loan = str_replace(",", "", $_POST['loan_amount']);
  $interest = $_POST['interest'];
  $period = $_POST['period'];
  $duration = $_POST['duration'];
  $date = $_POST['date'];

  $update = mysqli_query($connect,"UPDATE loan_entries SET loan_amount='$loan',interest='$interest',period='$period',duration='$duration',date_entry='".date("Y-m-d",strtotime($date))."' WHERE id='$id' ");
  if(mysqli_affected_rows($connect)){
    echo '<script type="text/javascript">
       location.replace("loan_activity.php?action_msg=success&page='.$page.'&limit='.$limit.'&client='.$client.'&client2='.$client2.'&month='.$month.'&year='.$year.'&pay_status='.$pay_status.'&date='.$date.'");
     </script>';
  }else{    
    echo '<script type="text/javascript">
        location.replace("loan_activity.php?action_msg=err&reason='.$id.'&page='.$page.'&limit='.$limit.'&client='.$client.'&client2='.$client2.'&month='.$month.'&year='.$year.'&pay_status='.$pay_status.'&date='.$date.'");
      </script>';
  }
}

if($_POST['action']=='extend'){

  $loan = $_POST['loan'];
  $clientid=$_POST['loan_client'];

  $upd = mysqli_query($connect,"UPDATE loan_entries SET status='00', overdue_status='00' WHERE id='$loan'");
  $id=date("j").rand(10000000,99999999);
  if($upd){
     $date=date("Y-m-d",strtotime($_POST['date']));
     $sql = mysqli_query($connect,"INSERT INTO loan_entries VALUES('$id','".$_POST['new_loan']."','".$_POST['interest']."','".$_POST['duration']."','".$_POST['period']."','$date','01','".$_POST['loan_client']."','') ");
      if($sql){
         $status=1;
         mysqli_query($connect,"INSERT INTO loan_adjusts VALUES('".date("j").rand(10000000,99999999)."','$loan','$clientid','".date('Y-m-d')."') ");
       }else{
         $status=0;
         $err=mysqli_error($connect);
      }
}

  if($status==1){
    echo '
      <script type="text/javascript">
        location.replace("loan_activity.php?action_msg=success&client='.$clientid.'&loan='.$loan.'&page='.$page.'&limit='.$limit.'&client='.$client.'&client2='.$client2.'&month='.$month.'&year='.$year.'&pay_status='.$pay_status.'&date='.$date.'")
      </script>';
     }else if($status==0){
      echo '<script type="text/javascript">
        location.replace("loan_activity.php?action_msg=err&reason='.$err.'&page='.$page.'&limit='.$limit.'&client='.$client.'&client2='.$client2.'&month='.$month.'&year='.$year.'&pay_status='.$pay_status.'&date='.$date.'");
      </script>';
     }
}

// Returns Title of Search Results
    $search = ''; 

         if($client_id){
              $sql = mysqli_query($connect,"SELECT * FROM clients WHERE id='$client_id'");
              $r = mysqli_fetch_array($sql);
              $search .= ", ".$r[1].' '.$r[2];
            }else{
              if($client)
              $search .= ", ".$client;
            }
           if($date && $date2){
               $search .= ', '.date('d/m/Y',strtotime($date)).' To '.date('d/m/Y',strtotime($date2));
              }else if($date!='' && $date2==''){
                $search .= ', '.date('d/m/Y',strtotime($date));
                }
              if($month)
                  $search .= ' '.$month;                
                if($year) 
                    $search .= ' '.$year;                  
                  if($pay_status=='01')
                      $search .= '&nbsp;,Defaulter(s) Category';            
                   if($pay_status=='02')
                       $search .= '&nbsp;,Non Defaulter(s) Category'; 
                      if($branch){
                           $sql = mysqli_query($connect,"SELECT * FROM branches WHERE id='$branch' ");
                                  $r = mysqli_fetch_array($sql);
                              $search .= ', '.$r[1];
                         } 

                         //End

if($_POST['pagination']){

         $page = $_POST['pagination'];
    }

$targetpage = "loan_activity.php";   //your file name  (the name of this file)

if($page) 
  $start = ($page - 1) * $limit;          //first item to display on this page
else
  $start = 0;                             //if no page var is given, set start to 0
   
$qry = "SELECT c.id, CONCAT(c.first_name,' ',c.last_name) as 'client_names', c.contacts, c.email, l.id as 'loan_id', l.loan_amount, l.interest, l.duration, l.period, l.date_entry, l.status, b.branch_name, c.data_id FROM clients c, loan_entries l, branches b ";
    if(!$_SESSION['general_user'])
       $qry .= ", user_log u ";
         $qry .= " WHERE c.id = l.client AND c.branch_id = b.id AND ";
          if(!$_SESSION['general_user'])
             $qry .= " u.user_branch = c.branch_id AND ";
            if($client_id)
               $qry .= " c.id = '$client_id' AND ";
             else if($_POST['client'])
               $qry .= " CONCAT(c.first_name,' ',c.last_name) LIKE  '%".$_POST['client']."%' AND ";              
          if($month != '')
               $qry .= " monthname(l.date_entry) = '".$month."' AND ";
            if($date !='' && $date2 !='')
                      $qry .= " l.date_entry BETWEEN '".date('Y-m-d',strtotime($date))."' AND '".date('Y-m-d',strtotime($date2))."' AND ";
              if($date != '' && $date2=='')
                     $qry .= " l.date_entry = '".date('Y-m-d',strtotime($date))."' AND ";
                if($year != '')
                   $qry .= " date_format(l.date_entry,'%Y') = '".$year."' AND ";
                     if($pay_status)
                         $qry .=  " l.status = '".$pay_status."' AND ";
                    if(!$_SESSION['general_user'])
                       $qry .= "u.id='".$_SESSION['session_id']."' AND ";
                     if($branch)
                         $qry .= " b.id = '$branch' AND ";
                  $qry2 .= $qry.' 1 ';
              $qry .= " 1 ORDER BY l.date_entry DESC LIMIT $start, $limit ";
              
   $query = mysqli_query($connect,$qry2);//total loans registered
   $total_pages = mysqli_num_rows($query);
      
    $result = mysqli_query($connect,$qry);

    /* Setup page vars for display. */
    if ($page == 0) $page = 1;  //if no page var is given, default to 1.
    $first=1;
    $prev = $page - 1;
    
    $lastpage = ceil($total_pages/$limit);      //lastpage is = total pages / items per page, rounded up. 

    //previous page is page - 1 
    if($page==$lastpage)
    $next=$lastpage;
    else
    $next = $page + 1; //next page is page + 1 

    $lpm1 = $lastpage - 1; //last page minus 1

       ?>
       <input type="hidden" id="srch_val" value="<?php echo $client.','.$client_id.','.$date.','.$date2.','.$month.','.$year.','.$pay_status ?>" />

   <!-- Main Content Wrapper -->
<div class="main_bd_wrap">
  
  <?php        
    tp_hdr(); //Page Header, Menu
       side_menu_content(); // Side Menu
      ?>
         <!-- Main Content Side-Right -->
           <div class="main-sidebar col-lg-9">
            <?php if($_GET){ include('../data_files/action_msg.php'); } ?>
            
   <div class="grid-2" style="display: grid;">
        <div></div>
        <div style="text-align: right;">
          <!--Search Wrapper -->
           <form name="form1" method="post" action="loan_activity.php" id="form1">
             <div style="width:100%;height:40px;display: grid;grid-template-columns: 2fr 1fr;">
               <div style="height:40px;border:solid 1px #CCC;background-color:#fff">
                  <input type="text" class="search_text" name="client" placeholder="Client" id="client" autocomplete="off" />
                      <img src="../img_file/search.png" id="open_search" data-usr="" width="18px" height="18px" />
                       <input type="hidden" name="client_id" value="" id="client_id" />
                      <div id="drop-box" class="drop_down drop_large_size" style="width:336.7px;"></div>
                   </div> 
                 <input type="submit" name="search" value="Search" class="button_search">
              </div>                      
           </form>
       </div>
    </div>
  
   <div class="report_wrap">
   <div id="header_wrap">
          <div id="header_tpl"><?php echo po_address($connect) ?></div>
        </div>               
    <div class="report_header" style="align-items: center;">
                <span>Loans Performance Overview <?php echo $search ?></span>
                <span style="display:inline-block;text-align: right;font-size: 12px;font-weight: normal;">
                  <span id="get_report" style="display: inline-block;margin-right: 10px;border-radius: 5px;background-color: #ccc;padding: 5px;cursor: pointer;">Generate PDF</span>
                  <span id="print_rpt">
                    <span>Print</span>
                    <span><img src="../img_file/print-icon.svg" width="20" height="20"></span>
                  </span>
                </span>
               </div>
          </div>
<div class="report_wrap">
  <div class="report_header" style="font-size:12px;font-weight: normal;">
    <span>Loans Disbursed : <?php echo $total_pages ?></span>
    <span style="display: inline-block; text-align: right;font-size: 12px;font-weight: bold;">
          <form name="form2" method="post" action="loan_activity.php">
             <input type="hidden" value="<?php echo $client ?>" name="client" id="client" />
             <input type="hidden" value="<?php echo $client_id ?>" name="client_id" id="client2" />
             <input type="hidden" value="<?php echo $month ?>" name="month" id="month" />
             <input type="hidden" value="<?php echo $year ?>" name="year" id="year" />
             <input type="hidden" value="<?php echo $date ?>" name="date" id="date" />
             <input type="hidden" value="<?php echo $date2 ?>" name="date2" id="date" />
             <input type="hidden" value="<?php echo $pay_status ?>" name="pay_status" id="pay_status" />
          <?php 
             echo "<a href=\"$targetpage?page=$first&limit=$limit&client=$client&client_id=$client_id&month=$month&year=$year&pay_status=$pay_status&date=$date&date2=$date2&branch=$branch\">First</a>&nbsp;&nbsp;<a href=\"$targetpage?page=$prev&limit=$limit&client=$client&client_id=$client_id&month=$month&year=$year&pay_status=$pay_status&date=$date&date2=$date2&branch=$branch \">Prev</a>&nbsp;&nbsp;".$page.' of '.$lastpage."&nbsp;&nbsp;<a href=\"$targetpage?page=$next&limit=$limit&client=$client&client_id=$client_id&month=$month&year=$year&pay_status=$pay_status&date=$date&date2=$date2&branch=$branch\">Next</a>&nbsp;&nbsp;<a href=\"$targetpage?page=$lastpage&limit=$limit&client=$client&client_id=$client_id&month=$month&year=$year&pay_status=$pay_status&date=$date&date2=$date2&branch=$branch\">Last</a>" ?>
             
             <!-- Row Number
               <select name="rows" onchange="form.submit();" style="height:30px;width:60px"> 
                       <?php
                         $array = array("40","100","250","500","All");
                         foreach($array as $nums){
                           if($_POST['rows']){
                             if($_POST['rows']==$nums){
                               echo '<option value="'.$nums.'" selected="selected">'.$nums.'</option>';
                             }else{
                               echo '<option value="'.$nums.'">'.$nums.'</option>';
                             }
                           }else{
                             echo '<option value="'.$nums.'">'.$nums.'</option>';
                           }
                         }
                       ?>
                    </select>-->
              </form>
            </span>
        </div>
</div>
 
  <table align="center" cellpadding="5" cellspacing="0" width="100%" class="report_display">                
     <tr>
      <td>No</td>
      <td>Issue Date</td>
      <td>Id</td>
      <td>Client</td>
      <td>Branch</td>      
      <td>Status (Days)</td>
      <td align="center">Loan</td>
      <td align="center">Payments</td>
      <td align="right">Balance</td>
      <td></td>
     </tr>
     <tr>
      <td colspan="6"></td>
      <!-- <td style="color: #145FA7;" align="center">Interest</td>-->
      <td align="center"></td>
      <td></td>
      <td></td>
     </tr>
     <?php

       if(mysqli_num_rows($result)){

        $count=0;
        $total_loan=0;
        $total_pay=0;
        $total_bal=0;

        while($rw=mysqli_fetch_array($result)){

          $loan=(round($rw[6]/100,2)*$rw[5])+$rw[5];
          $acc_int=0;
          $bal=0;
          $overdue = "";
          $count += 1;

          $total_pay += $rw['amount_paid'];
         
         if($rw[10]=='00'){
            $status_period=0;
          }else{
            $status_period = ($rw[8]-return_period($rw[9],$rw[7]));//returns period remain for loan
           }
          
          if($status_period<0){
                $overdue=1;
               };
        ?>
        <tr>
         <td><?php echo $start+=1 ?></td>
         <td><?php echo date("d-m-Y",strtotime($rw[9])) ?></td>
         <td><?php echo $rw['data_id'] ?></td>
         <td style="text-transform:capitalize;"><?php echo strtolower($rw[1]) ?></td>  
         <td><?php echo $rw['branch_name'] ?></td>       
         <td><?php 
              if($overdue){ 
                echo '<span style="color:#F00">'.$status_period.'</span>';
                mysqli_query($connect,"UPDATE loan_entries SET status='02' WHERE id = '".$rw['loan_id']."' ");
               }else{
                  echo '<span>'.$status_period.'</span>';
            } ?></td>
         <td align="right"><?php echo number_format($rw[5]) ?></td>
         <td align="right"><?php echo number_format(loan_status($connect,$rw['loan_id'],'payments')); $total_pay += loan_status($connect,$rw['loan_id'],'payments')  ?></td>
         <td align="right"><?php
          if(mysqli_num_rows(mysqli_query($connect,"SELECT * FROM loan_adjusts WHERE loan = '$rw[4]' "))){
            $total_loan_balance+=0;
            echo 0;
          }else{

          $total_loan_balance += loan_status($connect,$rw['loan_id'],$status);
            echo number_format(loan_status($connect,$rw['loan_id'],$status));
        }            
      ?></td>
      <td>
        <input type="hidden" name="clientId" id="postClient_<?php echo $count ?>" value="<?php echo $rw[0] ?>" />
        <select name="select_action" class="text-input" id="action_<?php echo $count ?>" style="width:80px;">
             <option value="" selected="selected">Action</option>
             <option value="<?php echo $rw[4] ?>_loan" >Pay Loan</option>
             <option value="<?php echo $rw[4] ?>_amortize">Preview Amortization</option>
             <option value="<?php echo $rw[4] ?>_statement">View Statement</option>
             <?php if(!$rw['amount_paid']){
               //edit only loan has no payment
              ?>
               <option value="<?php echo $rw[4] ?>_edit" id="edit2_<?php echo $count?>">Edit Loan</option>
               <option value="<?php echo $rw[4] ?>_delete" id="delete_<?php echo $count?>">Delete</option>
              <?php } ?>
          </select>
         </td>
       </tr>
        <?php
          $total_loan += $rw[5];
          
          $total_bal += $bal; 
        }
        ?>
         <tr style="font-weight:bold;">
           <td colspan="6">Total</td>
           <td align="right"><?php echo number_format($total_loan) ?></td>
           <!--<td align="right"><?php echo number_format($total_int_pay) ?></td>-->
           <td align="right"><?php echo number_format($total_pay) ?></td>
           <td align="right"><?php echo number_format($total_loan_balance) ?></td>
           <td></td>
         </tr>
        <?php
       }else{
          ?>
          <tr>
            <td style="height:100px;width:70%" colspan="9">
             No Result(s) Found.
            </td>
          </tr>
          <?php
        }
      ?>
       <tr>
          <td colspan="10">
           <div style="float:left;" id="page_break"></div></td>
       </tr>
    </table>
  </div>
</div>

<!-- Search Form -->
<div id="search-form">
  <input type="hidden" name="post_search" value="1" />
    <div class="form_element">
  <input type="text" name="date" placeholder="Date From" class="text-input" id="datetimepicker" autocomplete="off" />
    </div>
    <div class="form_element">
     <input type="text" name="date2" placeholder="Date To" class="text-input" id="picker" autocomplete="off" />
    </div>
    <div class="form_element">
      <select name="month" id="month" class="text-input">
        <option selected="selected" value="">Search Month</option>
         <?php 
          $array_month = array('January','February','March','April','May','June','July','August','September','October','November','December');
          foreach($array_month as $val){
            echo '<option value="'.$val.'">'.$val.'</option>';
          }
        ?>
      </select>
    </div>
    <div class="form_element">
     <input type="text" name="year" placeholder="Year" class="text-input" id="year" autocomplete="off" />
    </div>
    <?php
      if($_SESSION['general_user']) { ?>
<div class="form_element">
  <select name="branch_details" class="text-input">
    <option value="" selected="selected">Search Branch</option>
     <?php
       $sql = mysqli_query($connect,"SELECT * FROM branches");
         if(mysqli_num_rows($sql)){
            while($r = mysqli_fetch_array($sql)){
              if($r[1])
               echo '<option value="'.$r['id'].'">'.$r['branch_name'].'</option>';
             }
           }
         ?>
       </select>
</div>
<?php } ?>

 <div class="form_element" style="font-size: 13px;">
     <input type="radio" name="pay_status" class="input_layout" id="radio1" value="02" />&nbsp;&nbsp;Defaulters
     <br>
     <input type="radio" name="pay_status" class="input_layout" id="radio2" value="00" />&nbsp;&nbsp;Non Defaulters
    </div>
</div>
    <?php
      echo footer_sec(); //footer section
    ?>
  </div>
  </body>
</html>