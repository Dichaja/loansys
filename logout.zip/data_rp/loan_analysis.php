<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require("../xsert/connect.php");
require_once('../data_files/sys_function.php');
require_once('../data_files/page_settings.php');

check_sess(); //check user loggin

function return_monthly_loans($c,$month,$year){
      $qry = "SELECT * FROM loan_entries WHERE ";
        if($month!=''){
          $qry.= " monthname(date_entry) = '$month' AND ";
         }
          if($year!=''){
            $qry.= " date_format(date_entry,'%Y') = '$year' AND ";
             }
           $qry.=" 1 ";
      $sql = mysqli_query($c,$qry);
      while($rw=mysqli_fetch_array($sql)){
         $loan .= $rw[0].",";
      }
  return $loan;
}

if($_POST['search']){
  $year = $_POST['year'];
  $month = $_POST['month'];
  $date = $_POST['date'];
  $date2 = $_POST['date2'];
}else{
  $year = date("Y");
}

?>
<!DOCTYPE html>
<html lang="en">
  <head>
   <meta content="charset=utf-8" /> 
    <?php include('../data_files/link_docs.php') ?>
   <title><?php echo sys_tab_hdr() ?></title>

<script type="text/javascript">
$(function(){

 var year = $('#year_search').val();
 var total = $("#total").html();
 var total_split = total.split('.');
     total_split[0] = total_split[0].replace(/[^0-9]/g,"");
    $.ajax({
      type:'POST',
      url:'json_file.php',
      data:{
        'year':year
      },success:function(d){
        $("#bal_frwd").html(seperator(d));
        $("#grand").html(seperator(d+parseFloat(total_split[0])));

    }
  });
})

function seperator(index){
   var myVal="";
   var myDec="";
   var index_val="";
   var amtVal = parseFloat(index).toFixed(2);
   var amt_split = amtVal.toString().split('.');

      // Filtering out the trash!
        amt_split[0] = amt_split[0].replace(/[^0-9]/g,""); 

      // Setting up the decimal part
        if ( ! amt_split[1] && amtVal.indexOf(".") > 1 ) {myDec = "."}
        if ( amt_split[1] ) { myDec = "."+ parseFloat(amt_split[1]) }

  // Adding the thousand separator
        while(amt_split[0].length > 3 ) {
            myVal = ","+amt_split[0].substr(amt_split[0].length-3, amt_split[0].length )+ myVal;
            amt_split[0]= amt_split[0].substr(0, amt_split[0].length-3);           
          }
        index_val = (amt_split[0]+myVal+myDec); 
    return index_val;
}
</script>
</head>

<body>
   
   <!-- Main Content Wrapper -->
<div class="main_bd_wrap">
  
  <?php        
    tp_hdr(); //Page Header, Menu
       side_menu_content(); // Side Menu
      ?>
         <!-- Main Content Side-Right -->
           <div class="main-sidebar col-lg-9">
             <div style="width:100%;height:40px;margin-bottom:10px;padding:5px;">
                      <span class="header"><?php
                         $search_text='';
                       if($date && $date2){
                             $search_text .= ', '.date('d/m/Y',strtotime($date)).' To '.date('d/m/Y',strtotime($date2));
                            }else if($date!='' && $date2==''){
                               $search_text .= ', '.date('d/m/Y',strtotime($date));
                           }
                       if($month){
                          $search_text .= ' '.$month;
                        }
                        if($year){
                            $search_text .= ' '.$year;
                         }
                           echo $search_text;
                         ?></span>
                <div style="float:right;width:70%;margin-bottom:15px;" class="search">
                  <div style="float:right;width:40%;margin-right:40px;">
                   <form name="search-form" id="search-forms" method="post" action="">                    
                     <input type="hidden" name="year_search" id="year_search" value="<?php echo $year ?>" autocomplete="off" />
                        <div style="float:right;">
                         <input type="submit" name="search" value="Go" class="search_button" /></div>
                         <div style="width:78%;background-color:#fff;border:solid 1px #CCC;">
                         <input type="text" class="search_text" name="year" placeholder="Year" id="year" />
                          <img src="../img_file/search.png" width="18px" height="18px" style="cursor:pointer;" id="open_search" /></div>                               
                          <div id="suggesstion-box" class="suggest"></div>
                          <input type="hidden" name="staff" value="" id="staff" />
                        </form>
                      </div>
                    </div>
          </div>
  <div class="report_header"><span>General Loan Performance </span><span id="print_rpt"><img src="../img_file/print-icon.svg" width="20" height="20"></span></div>
    <table align="center" cellpadding="4" cellspacing="0" width="100%" class="report_display">
     <?php
     $month_array = array('January','February','March','April','May','June','July','August','September','October','November','December');
     ?>
      <tr style="font-weight:bold;">
        <td class="bottom_line">&nbsp;</td>
        <td class="bottom_line">Period</td>
        <td class="bottom_line">Disburments</td>
        <td class="bottom_line">Amount Disbursed</td>
        <td class="bottom_line">Expected Interest</td>
        <td class="bottom_line" colspan="2" >Actual Collection</td>
      <tr>
      <tr>
        <td class="bottom_line" colspan="5"></td>
        <td class="bottom_line">Interest + Principal</td>
        <td class="bottom_line"></td>
      <tr>
      <tr>
        <td class="bottom_line" colspan="5">Annual Collection Brought Foward</td>
        <td class="bottom_line"><span id="bal_frwd"></span></td>
        <td class="bottom_line"></td>
      <tr>
      <?php
        $count=0;
        
        foreach($month_array as $month_index){
          $count += 1;
          $month_tot = 0;
          $sql = "SELECT loan_amount, id, interest, period, date_entry  FROM loan_entries WHERE ";            
                if($month != ''){
                  $sql .= " monthname(date_entry)='$month' AND ";
                 }else{
                  $sql .= " monthname(date_entry)='$month_index' AND ";
                 }
                  if($date !='' && $date2 !=''){
                      $sql .= " date_entry BETWEEN '".date('Y-m-d',strtotime($date))."' AND '".date('Y-m-d',strtotime($date2))."' AND ";
                      }
                   if($date != '' && $date2==''){
                     $sql .= " date_entry = '".date('Y-m-d',strtotime($date))."' AND ";
                     }
                  if($year != ''){
                    $sql .= " date_format(date_entry,'%Y') = '$year' AND ";
                   }
                    $sql .= " 1 ";
              $qry = mysqli_query($connect,$sql); 
              $qry2 = mysqli_query($connect,$sql); 
          while($rw = mysqli_fetch_array($qry)){
            $month_tot += $rw[0];
          }
         ?>
          <tr>
            <td class="bottom_line" style="font-weight:bold"><?php echo $count ?></td>
            <td class="bottom_line" style="font-weight:bold"><?php echo $month_index ?></td>
            <td class="bottom_line"><?php
               if($month){
                 if($month==$month_index){
                   echo mysqli_num_rows($qry);
                 }else{
                   echo 0;                  
                 }
               }else{
                  echo mysqli_num_rows($qry);
               }
            ?></td>
            <td class="bottom_line"><?php
               if($month){
                 if($month==$month_index){
                   $disbursed = $month_tot;
                 }else{
                   echo 0;
                   $month_tot=0;
                   $disbursed = $month_tot;
                 }
               }else{
                  $disbursed = $month_tot;
               }
               echo number_format($disbursed);
               $total_disbursed += $disbursed;
            ?></td>
            <td class="bottom_line">
            <?php
                $total_expected_int=0;///returns total expect_interest

               if($_POST){              
                if($month==''){
                  while($rw=mysqli_fetch_array($qry2)){

                  //$acc_interest='';
                  $x=0;
                  $acc_principal=0;
                 for($i=0; $i<$rw[3]; $i++){
                  //pinicpal = loan / period
                  $int_val = $rw[2];
                  $loan = $rw[0];
                  $principal = $rw[0]/$rw[3];
                  $int_rate=($rw[2]/100);
                  $monthly_rate = round($int_rate/$rw[3],2);
                  $interest = $monthly_rate*$principal;
                  $acc_principal += $principal; 
                  $x +=  return_int($rw[2],$rw['duration'],$principal,$loan);                  
                  }
                  $total_expected_int += $x;
                  }
                }

                if($month==$month_index){
                while($rw=mysqli_fetch_array($qry2)){

                  //$acc_interest='';
                  $x=0;
                  $acc_principal=0;
                 for($i=0; $i<$rw[3]; $i++){
                  //pinicpal = loan / period
                  $int_val = $rw[2];
                  $loan = $rw[0];
                  $principal = $rw[0]/$rw[3];
                  $int_rate=($rw[2]/100);
                  $monthly_rate = round($int_rate/$rw[3],2);
                  $interest = $monthly_rate*$principal;
                  $acc_principal += $principal; 
                  $x +=  return_int($rw[2],$rw['duration'],$principal,$loan);                  
                  }
                  $total_expected_int += $x;
                }
             }else{                   
                   $total_expected=0;
                   $acc_interest='';
                 }                
               }else{
                 while($rw=mysqli_fetch_array($qry2)){

                  //$acc_interest='';
                  $x=0;
                  $acc_principal=0;
                 for($i=0; $i<$rw[3]; $i++){
                  //pinicpal = loan / period
                  $int_val = $rw[2];
                  $loan = $rw[0];
                  $principal = $rw[0]/$rw[3];
                  $int_rate=($rw[2]/100);
                  $monthly_rate = round($int_rate/$rw[3],2);
                  $interest = $monthly_rate*$principal;
                  $acc_principal += $principal; 
                  $x +=  return_int($rw[2],$rw['duration'],$principal,$loan);                  
                  }
                  $total_expected_int += $x;
                }
               }
              echo number_format($total_expected_int);
              $total_int += $total_expected_int;
            ?>
            </td>            
            <td class="bottom_line" colspan="2">
             <?php
                 if($_POST){
                 if($month==$month_index){
                   $month_qry = $month;                
                }
                if($month==''){
                  $month_qry=$month_index;
                }
               }else{
                  $month_qry=$month_index;
               }
                 $select = "SELECT amount_paid, loan FROM loan_payments WHERE ";
                    if($month_qry != ''){
                      $select .= " monthname(pay_date) = '$month_qry' AND ";
                    }
                    if($date !='' && $date2 !=''){
                      $select .= " pay_date BETWEEN '".date('Y-m-d',strtotime($date))."' AND '".date('Y-m-d',strtotime($date2))."' AND ";
                      }
                   if($date != '' && $date2==''){
                     $select .= " pay_date = '".date('Y-m-d',strtotime($date))."' AND ";
                     }
                    if($year != ''){
                      $select .= " date_format(pay_date,'%Y') = '$year' AND ";
                    }
                     $select .= " 1 ";
                     $sqls = mysqli_query($connect,$select);

                     $pay=0;
                     $amt=0;
                     while($rw=mysqli_fetch_array($sqls)){
                       $pay += $rw[0];
                       /*$loan_pay = mysqli_query($connect," SELECT * FROM loan_entries WHERE id='$rw[1]' ");
                       $result=mysqli_fetch_array($loan_pay);
                       $amt += loan_balances($connect,$result[4],$result[2],$result[1],$rw[1],$result[5],$result[3],$row[6],"payments"); */                      
                     }
                     
                     
                     if($_POST){
                     if($month==$month_index){                   
                        echo number_format($pay);    
                        $total_pay += $pay;            
                      }else if($month==''){
                       echo number_format($pay);
                       $total_pay += $pay;
                     }else{
                        echo $pay=0;

                     }
               }else{
                  echo number_format($pay);
                  $total_pay += $pay;
               }
              
            ?>
            </td>
          </tr>
         <?php
        }
      ?>
      <tr style="font-weight:bold;">
        <td class="bottom_line" style="font-weight:bold" colspan="3">Total</td>
        <td class="bottom_line" style="font-weight:bold"><?php echo number_format($total_disbursed)?></td>
        <td class="bottom_line" style="font-weight:bold"><?php echo number_format($total_int)?></td>
        <td class="bottom_line" style="font-weight:bold" id="total"><?php echo number_format($total_pay) ?></td>
      <tr>
       <tr style="font-weight:bold;">
        <td class="bottom_line" style="font-weight:bold" colspan="3">Grand Total</td>
        <td class="bottom_line" style="font-weight:bold"></td>
        <td class="bottom_line" style="font-weight:bold"></td>
        <td class="bottom_line" style="font-weight:bold"><span id="grand"></span></td>
      <tr>
    </table>
    <div style="float:left;height:250px;width:100%">&nbsp;</div>
  </div> 
</div>

<!-- returns seach form elements -->
<div id="search-form">    
    <div class="form_element">
      <input type="text" name="date" id="datetimepicker" class="text-input" placeholder="Date 1" autocomplete="off" />
    </div>
    <div class="form_element">
      <input type="text" name="date2" id="picker" class="text-input" placeholder="Date 2" autocomplete="off" />
    </div>
    <div class="form_element">
      <select name="month" id="month" class="select-input">
        <option selected="selected" value="">--Month--</option>
         <?php 
          $array_month = array('January','February','March','April','June','July','August','September','October','November','December');
          foreach($array_month as $val){
            echo '<option value="'.$val.'">'.$val.'</option>';
          }
        ?>
      </select>
    </div>
    <div class="form_element">
      <input type="submit" name="search" value="Search" class="button-input-small" />
    </div>
</div>

    <?php
      echo footer_sec(); //footer section
    ?>
  </div>
  </body>
</html>