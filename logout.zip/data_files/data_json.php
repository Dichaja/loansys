<?php

session_start();

require_once("../xsert/connect.php");
error_reporting(E_NOTICE ^ E_ALL);

header('Content-Type: application/json');

$search = $_POST['search'];
$qry = "SELECT SUM(l.loan_amount) as 'total_loan', monthname(l.date_entry) as 'month' FROM clients c, loan_entries l, branches b ";
    if(!$_SESSION['general_user'])
       $qry .= ", user_log u ";
         $qry .= " WHERE c.id = l.client AND c.branch_id = b.id AND ";
      if(!$_SESSION['general_user'])
             $qry .= " u.user_branch = c.branch_id AND ";
          if(!$_SESSION['general_user'])
                       $qry .= "u.id='".$_SESSION['session_id']."' AND ";
                  $qry .= ' 1 GROUP BY month ';
     $sql = mysqli_query($connect,$qry);

if(mysqli_num_rows($sql)){
    while($r=mysqli_fetch_array($sql)){
     $array_loan[]=array('account'=>'Loans','month'=>$r[1],'amount'=>$r[0]);
    }
}

$qry  = "SELECT SUM(p.amount_paid) as 'total_pay', monthname(p.pay_date) as 'month' FROM clients c, loan_entries l, branches b, loan_payments p ";
    if(!$_SESSION['general_user'])
       $qry .= ", user_log u ";
         $qry .= " WHERE c.id = l.client AND c.branch_id = b.id AND p.loan = l.id AND ";
      if(!$_SESSION['general_user'])
             $qry .= " u.user_branch = c.branch_id AND ";
          if(!$_SESSION['general_user'])
                       $qry .= "u.id='".$_SESSION['session_id']."' AND ";
                  $qry .= ' 1 GROUP BY month ';

$sql = mysqli_query($connect, $qry);
if(mysqli_num_rows($sql)){
    while($r=mysqli_fetch_array($sql)){
     $array_loan[]=array('account'=>'Payments','month'=>$r[1],'amount'=>$r[0]);
    }
}

print json_encode($array_loan);

?>