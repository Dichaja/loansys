<?php
session_start();
error_reporting(E_ALL ^ E_NOTICE);
require("../xsert/connect.php");
require_once('../data_files/sys_function.php');
require_once('../data_files/page_settings.php');

check_sess(); //check user loggin

?>
<!DOCTYPE html>
<html lang="en">
  <head>
   <meta content="charset=utf-8" /> 
    <?php include('link_docs.php') ?>
   <title><?php echo sys_tab_hdr() ?></title>

<script type="text/javascript">

$(document).on('keyup','#staff_names',function() {

  var  search = $(this).val();
  var exp = new RegExp(search, "i");
  var results='',count=0, combo;

if(search){
  $.ajax({
    type:'POST',
    url:'../data_files/name_list.php',
    data:{
      'search':search,
      'name_cat': 'staff'
    },
    beforeSend:function(){
      $("#drop-box").slideDown().html('<div style="margin:auto;max-height250px;margin-bottom:50px;margin-top:50px;width:40%;"><img src="../img_file/loading.gif" /></div>');
    },success:function(data){
      $.each(data,function(key,value){
      combo = value.first_name+' '+value.last_name;
      combo2 = value.last_name+' '+value.first_name;
       if(value.first_name.search(exp) != -1 || value.last_name.search(exp) != -1 || combo.search(exp) != -1 || combo2.search(exp) != -1){
        count+=1;
         results += '<div class="list_items" data="'+value.id+'">'+value.first_name+' '+value.last_name+'</div>';
        }
     })

     if(results)
      $("#drop-box").html(results);
     else 
      $("#drop-box").slideUp();
    }
  })
} 
else 
  $("#drop-box").slideUp();
})

$(document).on('click','.list_items',function(){

   var id = $(this).attr('data');
   var txt = $(this).html();

   $('#staff_names').val(txt).css('text-transform','capitalize');
   $('#staff_id').val(id);
   $('#drop-box').slideUp();
 })

$(document).on('change','select[name="option[]"]',function(){
  
   var val = $(this).val();
   var split = val.split('_');
   var modal = $('#myModal').html();

   if(split[1]=='delete'){
    
      if(confirm("Do You Want to Delete User...?")){
         $.ajax({
           type: 'POST',
           url: 'data_src.php',
           data:{
             'del_id': split[0],
             'del_tab' : 'user_log'
           },
          beforeSend:function(){
          $('#myModal').css({'display':'block','z-index':'6'}).html('<div class="modal-spin-wrap"><div class="modal-img-spin"><img src="../img_file/loading.gif" /></div></div>')
         },
          success:function(d){
               $('#myModal').html(modal);
                $('.modal-content').toggleClass('modal-min-size')
                if(d=='success')
                   content = $('#success_wrap').html();
                else
                   content = $('#error_wrap').html();           
            $('#display').html(content);
         }
      })
    }else{
      return false;
    }
  }

  if(split[1]=='restore'){
     
      $.ajax({
         type: 'POST',
         url: 'data_src.php',
         data: {
           'restore_usr': split[0]
         },
         beforeSend:function(){
          $('#myModal').css({'display':'block','z-index':'6'}).html('<div class="modal-spin-wrap"><div class="modal-img-spin"><img src="../img_file/loading.gif" /></div></div>')
         },
          success:function(d){
               $('#myModal').html(modal);
                $('.modal-content').toggleClass('modal-min-size')
                if(d=='success'){
                   content = $('#success_wrap').html();
                   $('#display').html(content);
                }
                else
                   $('#myModal').css('display','none')           
            
         }
      })
  }

  if(split[1]=='disable'){
     
      $.ajax({
         type: 'POST',
         url: 'data_src.php',
         data: {
           'disable_usr': split[0]
         },
         beforeSend:function(){
          $('#myModal').css({'display':'block','z-index':'6'}).html('<div class="modal-spin-wrap"><div class="modal-img-spin"><img src="../img_file/loading.gif" /></div></div>')
         },
          success:function(d){
               $('#myModal').html(modal);
                $('.modal-content').toggleClass('modal-min-size')
                if(d=='success'){
                   content = $('#success_wrap').html();
                   $('#display').html(content);
                }
                else
                   $('#myModal').css('display','none')           
            
         }
      })
  }

})

</script>
</head>

<body>

<?php

 if($_POST['submit']){

    $staff = $_POST['staff_id'];
    $email = $_POST['email'];
    $usr = $_POST['usr_name'];
    $pwd = $_POST['pwd'];
    $usr_type = $_POST['usr_type'];
    $pwd2 = $_POST['pwd2'];
   
   if($pwd==$pwd2){
    $inst = mysqli_query($connect,"INSERT INTO user_log VALUES('".rand(1000,9999)."','$staff','$usr', MD5('$pwd'),'$usr_type',NULL,'01','".date('Y-m-d H:i:s')."','".$_POST['branch_details']."') ");
    if($inst){
      $status  = 'success';
    }else{
      $status = 'err';
      $response = mysqli_error($connect);
    }
  }else {
      $mis_match=1;
      $staff_user = $usr;
      $initial_pwd = $pwd;
      $wrg_pwd = $pwd2;
    }

if($mis_match){
      ?>
      <script type="text/javascript">
        location.replace("add_user.php?action_msg=mis_match&user=<?php echo $usr ?>&names=<?php echo $names ?>&email=<?php echo $email ?>&pwd=<?php echo $initial_pwd ?>");
      </script>
    <?php
    }else{
    ?>
     <script type="text/javascript">
       location.replace("add_user.php?action_msg=<?php echo $status ?>&if_err=<?php echo $response ?>")
     </script>
    <?php
  }
}

?>  
   <!-- Main Content Wrapper -->
<div class="main_bd_wrap">
  
  <?php        
    tp_hdr(); //Page Header, Menu
       side_menu_content(); // Side Menu
      ?>
         <!-- Main Content Side-Right -->
           <div class="main-sidebar col-lg-9">
            <div class="form_wrap_min">

             <?php if($_GET){ include('action_msg.php'); } ?>

               <div class="form_header">Add User</div>   
       <form name="form1" id="form1" method="post" action="add_user.php">
        <input name="usr_id" type="hidden" value="" id="usr_id" />
            <div class="form-group">
                 <div class="label">Staff Name</div>
                <input type="textbox" name="staff_names" class="text-input" required="required" id="staff_names" autocomplete="off" required="" />
                <input type="hidden" name="staff_id" value="" id="staff_id">
                      <div id="drop-box" class="drop_down drop_large_size" style="width:572px;"></div>
             </div>
             <div class="form-group">
                <div class="label">User Name</div>
                <input type="textbox" name="usr_name" class="text-input" required="required" id="usr" autocomplete="off" required="" /></td>
             </div>
             <div class="form-group">
                <div class="label">Password</div>
                <input type="password" name="pwd" class="text-input" required="required" id="pwd" />
                <div id="pass" style="display:block;font-family:'Segoe UI';width:100%;float:right;margin-top:10px;"></div>
                </div>
             <div class="form-group">
                <div class="label">Confirm Password</div>
                <input type="password" name="pwd2" class="text-input" required="required" id="pwd2" />
                <div id="confirm2" style="display:block;float:right;width:100%;font-family:'Segoe UI'; color:#009900;margin-top:10px;"></div>
              </div>
            <div class="form-group">
                <div class="label">User Type</div>
                  <select name="usr_type" class="text-input" id="usr_type">
                     <option value="" selected="selected">Select</option>
                     <option value="admin">Admin</option>
                     <option value="director">Director</option>
                     <option value="data_clerk">Data Clerk</option>
                  </select>
             </div>
             <div class="form-group">
                           <div class="label">User Branch</div>
                             <select name="branch_details" class="text-input">
                               <option value="00010" selected="">Select</option>
                               <?php
                                  $sql = mysqli_query($connect,"SELECT * FROM branches");
                                   if(mysqli_num_rows($sql)){
                                     while($r = mysqli_fetch_array($sql)){
                                      if($r[1])
                                       echo '<option value="'.$r['id'].'">'.$r['branch_name'].'</option>';
                                     }
                                   }
                               ?>
                             </select>
                       </div>             
            <div class="form-group">
                 <input type="submit" name="submit" value="Submit" class="button-input" />
            </div>
       </form>
    </div>

    <div style="width:90%;margin: 30px auto;">
      <div class="report_header">
         <span>User Activity Log</span>
         <div id="print_rpt"><img src="../img_file/print-icon.svg" width="20" height="20"></div>
     </div>

       <table width="100%" cellpadding="5" cellspacing="0" align="center" class="report_display">        
         <tr>
           <td>No</td>
           <td>Staff</td>
           <td>Email</td>
           <td>User Name</td>
           <td>User Type</td>
           <td>User Branch</td>
           <td>Last Login</td>
           <td>User Status</td>
           <td>Date Set</td>
           <td></td>
         </tr>     
      <?php
      $q = "SELECT u.id, s.first_name, s.last_name, s.email, u.usr_name, u.usr_type, b.branch_name, u.log_date, u.action_status, u.date_set FROM  user_log u, staff s, branches b WHERE u.staff = s.id AND u.user_branch = b.id "; 
        $sql = mysqli_query($connect,$q);
     $no = 0;

     if(mysqli_num_rows($sql)){

      while($row=mysqli_fetch_array($sql)){
          ?>
          <tr id="status_<?php echo $x+=1 ?>">
           <td><?php echo $no+=1 ?></td>
           <td><?php echo $row['first_name'].' '.$row['last_name'] ?></td>
           <td><?php echo $row['email'] ?></td>
           <td><?php echo $row['usr_name'] ?></td>
           <td><?php echo $row['usr_type'] ?></td>
           <td><?php echo $row['branch_name'] ?></td>
           <td><?php 
                if(!$row['log_date'])
                     echo '00-00-0000 00:00';
                  else
                     echo date('d-m-Y H:i',strtotime($row['log_date'])); ?></td>
           <td><span style="color:#F00;"><?php 
                 if($row[8]=='01')
                      echo 'Active';
                   if($row[8]=='02')
                         echo 'Disabled';
                   ?></span></td>
           <td><?php echo date('d-m-Y H:i:s',strtotime($row['date_set'])) ?></td>
           <td align="right">
           <select name="option[]" style="height:30px; width:90px;" id="action_<?php echo $count ?>" class="text-input">
              <option value="" selected="selected">Action</option>
              <option value="<?php echo $row[0].'_edit' ?>">Edit</option>
              <?php
                if($row[8]=='01')
                  echo '<option value="'.$row[0].'_disable">Disable</option>';
                if($row[8]=='02')
                  echo '<option value="'.$row[0].'_restore">Restore</option>';
                if($row['usr_type']!='admin')
                   echo '<option value="'.$row[0].'_delete">Delete</option>';
               ?>
          </select>
        </td>
       </tr>
          <?php
      }
     }
     ?>      
      <tr>
         <td colspan="9"><div style="height:40px;">&nbsp;</div></td>
      </tr>
      </table>
    </div>
        </div>
    <?php
      echo footer_sec(); //footer section
    ?>
  </div>
  </body>
</html>